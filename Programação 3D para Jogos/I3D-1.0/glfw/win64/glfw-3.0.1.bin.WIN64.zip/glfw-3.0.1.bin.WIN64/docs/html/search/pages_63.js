var searchData=
[
  ['context_20handling_20guide',['Context handling guide',['../context.html',1,'']]]
];
